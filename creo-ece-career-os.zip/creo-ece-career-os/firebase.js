// ============================================================
// CREO ECE Career OS — firebase.js
// ⚠️  REPLACE ALL "YOUR_*" VALUES BEFORE DEPLOYING
// ============================================================

// ---- Firebase Config ----
// Get from: Firebase Console → Project Settings → Your Apps → Web App
const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};

// ---- OpenRouter API Key ----
// Get free key from: https://openrouter.ai/keys
// Free models: google/gemini-2.0-flash-exp:free, meta-llama/llama-3.1-8b-instruct:free
const OPENROUTER_API_KEY = "YOUR_OPENROUTER_API_KEY";

// ---- Cloudinary Config ----
// Sign up at https://cloudinary.com (free 25GB)
// Create an UNSIGNED upload preset in Settings → Upload
const CLOUDINARY_CLOUD_NAME   = "YOUR_CLOUD_NAME";
const CLOUDINARY_UPLOAD_PRESET = "YOUR_UPLOAD_PRESET";

// ============================================================
// Firestore Security Rules — paste in Firebase Console
// ============================================================
/*
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      match /{subcollection}/{docId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
*/

// ============================================================
// Firestore Database Structure (reference only)
// ============================================================
/*
users/{uid}/
  ├── (root doc)      → { name, email, college, branch, semester, cgpa,
  │                       targetCgpa, goal, bio, avatarUrl, roadmapProgress,
  │                       cyberSkills, createdAt }
  ├── subjects/       → [{ name, code, credits, internalMark, attendance, examDate }]
  ├── studySessions/  → [{ date, subject, duration, pomodoroCount, notes }]
  ├── habits/         → [{ name, icon, streak, completedDates[], targetDays }]
  ├── notes/          → [{ title, subject, type, cloudinaryUrl, publicId, tags[] }]
  ├── certifications/ → [{ name, provider, status, completedDate, credentialUrl, category }]
  ├── internships/    → [{ company, role, type, status, startDate, endDate, stipend }]
  ├── projects/       → [{ title, description, techStack[], githubUrl, liveUrl, status }]
  └── ctfChallenges/  → [{ name, platform, category, points, solved, date }]
*/
